<?php $my_js_map = $this->options; ?>

<form method="post" action="<?php echo esc_url(admin_url('admin.php?page=my-js-map')); ?>">
    <?php
    settings_fields(__FILE__);
    do_settings_sections(__FILE__);
    ?>
  <?php wp_nonce_field('my_js_map_nonce_action', 'my_js_map_nonce'); ?>

  <?php if ( $error_message = get_transient( 'nonce_error' ) ) {
    echo '<div class="error">' . esc_html( $error_message ) . '</div>';
    delete_transient( 'nonce_error' );
  } ?>
<div id="map-admin">

  <div id="map-header">
    <p class="map-shortcode"><?php esc_html_e( 'Insert this shortcode ', 'my-js-map' ); ?><input type="text" value="[my_js_map]" readonly> <?php esc_html_e( 'in any page or post to display the map.', 'my-js-map' ); ?> &nbsp; | &nbsp; <span class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_html_e( 'Save Changes', 'my-js-map' ); ?>"></span></p>
  </div>
  <div id="map-page">
    <div class="map-col-lt">
      <div id="map-preview">
        <?php include 'map.php'; ?>
      </div>
    </div><!-- map-col-lt -->

    <!-- General Map Colors -->
    <div class="map-col-rt">
      <div class="map-settings">
        <div class="box-header shape-icon"><?php esc_html_e( 'General Settings', 'my-js-map' ); ?></div>
        <div class="box-body">
          <div class="general-box"><span class="general-set i-border"><?php esc_html_e( 'Border Color', 'my-js-map' ); ?></span>
            <input type="text" name="borderColor" value="<?php echo esc_attr(sanitize_hex_color($my_js_map["borderColor"] ?? '') ?: ''); ?>" />
          </div>
          <div class="general-box"><span class="general-set i-show-hide"><?php esc_html_e( 'Show the Names', 'my-js-map' ); ?></span>
            <input type="checkbox" name="showNames" value="1" <?php if (isset($my_js_map['showNames']) && $my_js_map['showNames'] == '1') { echo esc_attr(" checked"); } ?>>
          </div>
          <div class="general-box"><span class="general-set i-abbs"><?php esc_html_e( 'Names Color', 'my-js-map' ); ?></span>
            <input type="text" name="namesColor" value="<?php echo esc_attr(sanitize_hex_color($my_js_map["namesColor"] ?? '') ?: ''); ?>" />
          </div>
          <div class="general-box"><span class="general-set i-abbs"><?php esc_html_e( 'Names Hover Color', 'my-js-map' ); ?></span>
            <input type="text" name="namesHoverColor" value="<?php echo esc_attr(sanitize_hex_color($my_js_map["namesHoverColor"] ?? '') ?: ''); ?>" />
          </div>
          <div class="general-box"><span class="general-set i-show-hide"><?php esc_html_e( 'Show the Callouts', 'my-js-map' ); ?></span>
            <input type="checkbox" name="showCallouts" value="1" <?php if (isset($my_js_map['showCallouts']) && $my_js_map['showCallouts'] == '1') { echo esc_attr(" checked"); } ?>>
          </div>
        </div><!-- box-body -->
      </div><!-- map-settings -->
      <div class="useful-links">
        <p class="mb-0"><strong>Useful links:</strong></p>
        <ul class="mt-0">
          <li>o <a href="<?php echo esc_url('https://www.html5interactivemaps.com/docs/malaysia-map/apps/modal/') ?>">How to Open Modal Windows?</a>.</li>
          <li>o <a href="<?php echo esc_url('https://www.html5interactivemaps.com/docs/malaysia-map/index.html#pins') ?>">How to Add Pins?</a>.</li>
          <li>o <a href="<?php echo esc_url('https://www.html5interactivemaps.com/docs/malaysia-map/apps/xyguide/') ?>">The X, Y Coordinates Guide</a>.</li>
          <li>o <a href="<?php echo esc_url('https://www.html5interactivemaps.com/docs/apps/html-editor/') ?>">Simple HTML Visual Editor</a>.</li>
          <li>o <a href="<?php echo esc_url('https://www.html5interactivemaps.com/docs/malaysia-map/') ?>">Full Documenation</a>.</li>
          <li>o <a href="<?php echo esc_url('https://www.html5interactivemaps.com/assets/contact.html') ?>">Need help? Contact Support</a>.</li>
        </ul>
      </div>
    </div><!-- map-col-rt -->
  </div><!-- map-page -->


  <div class="map-settings areas-settings">
    <div class="box-header individ-i"><?php esc_html_e( 'Settings', 'my-js-map' ); ?></div>
    <div class="box-body">


    <?php
    $total_areas = 16;
    $areas = range(1, $total_areas);
    $areas_title = [
    'JOHOR DARUL TA’ZIM', 'KEDAH DARUL AMAN', 'KELANTAN DARUL NAIM', 'KUALA LUMPUR', 'LABUAN', 'MELAKA', 'NEGERI SEMBILAN DARUL KHUSUS', 'PAHANG DARUL MAKMUR', 'PERAK DARUL RIDZUAN', 'PERLIS INDERA KAYANGAN', 'PULAU PINANG', 'PUTRAJAYA', 'SABAH', 'SARAWAK', 'SELANGOR DARUL EHSAN', 'TERENGGANU DARUL IMAN'
    ];
    ?>
    <?php foreach ($areas as $area): ?>

        <div class="map-area">
          <p class="area-name"><?php echo esc_html($areas_title[$area - 1]); ?></p>

          <!-- Active Checkbox -->
          <span class="chkbx">
            <input type="checkbox" name="active_<?php echo esc_attr($area); ?>" value="1" 
            <?php if (isset($my_js_map["active_$area"]) && $my_js_map["active_$area"] == '1') { echo esc_attr(" checked"); } ?> />
            &nbsp;<?php esc_html_e( 'Active', 'my-js-map' ); ?>
          </span>

          <div class="inner-content">
            <div class="area-clrs">
              <!-- Up Color -->
              <p>
                <label><?php esc_html_e( 'Up Color', 'my-js-map' ); ?></label>
                <input type="text" name="upColor_<?php echo esc_attr($area); ?>" 
                value="<?php echo esc_attr(sanitize_hex_color($my_js_map["upColor_$area"]) ?: '#FF0000'); ?>" />
              </p>

              <!-- Hover Color -->
              <p>
                <label><?php esc_html_e( 'Hover Color', 'my-js-map' ); ?></label>
                <input type="text" name="overColor_<?php echo esc_attr($area); ?>" 
                value="<?php echo esc_attr(sanitize_hex_color($my_js_map["overColor_$area"]) ?: '#FF0000'); ?>" />
              </p>
            </div>

            <div class="area-url">
              <!-- Link -->
              <p class="link">
                <label><?php esc_html_e( 'Link', 'my-js-map' ); ?></label>
                <input type="text" name="url_<?php echo esc_attr($area); ?>" 
                value="<?php echo esc_url( isset($my_js_map["url_$area"]) ? $my_js_map["url_$area"] : '' ); ?>" />
              </p>

              <!-- Target -->
              <p>
                <label><?php esc_html_e( 'Target', 'my-js-map' ); ?></label>
                <select name="turl_<?php echo esc_attr($area); ?>">
                  <option value="same_page" <?php selected($my_js_map["turl_$area"], 'same_page'); ?>><?php esc_html_e( 'Same Page', 'my-js-map' ); ?></option>
                  <option value="new_page" <?php selected($my_js_map["turl_$area"], 'new_page'); ?>><?php esc_html_e( 'New Page', 'my-js-map' ); ?></option>
                  <option value="none" <?php selected($my_js_map["turl_$area"], 'none'); ?>><?php esc_html_e( 'Modal / None', 'my-js-map' ); ?></option>
                </select>
              </p>
            </div>

            <div class="info">
              <p>
                <label><?php esc_html_e( 'Info.', 'my-js-map' ); ?></label>
                <textarea rows="1" name="info_<?php echo esc_attr($area); ?>"><?php echo esc_textarea( isset($my_js_map["info_$area"]) ? $my_js_map["info_$area"] : '' ); ?></textarea>
              </p>
            </div>
          </div>
        </div>
    <?php endforeach; ?>

    </div><!-- box-body / for areas -->
  </div><!-- map-settings / for areas -->

  <!-- //////////////  BULK EDIT ///////////// -->
  <div class="map-settings margin-top-10">
    <div class="box-header bulk-i"><?php esc_html_e( 'Bulk Edit', 'my-js-map' ); ?></div>
    <div class="box-body">

      <div class="map-area">
        <p class="area-name"><?php esc_html_e( 'COLORS', 'my-js-map' ); ?></p>
        <div class="inner-content">
          <div class="area-clrs">
            <p>
              <label><?php esc_html_e( 'Up Color', 'my-js-map' ); ?></label>
              <input type="text" name="upColor_all" 
              value="<?php echo esc_attr(sanitize_hex_color($my_js_map['upColor_1']) ?: '#FF0000'); ?>" />
            </p>
            <p>
              <label><?php esc_html_e( 'Hover Color', 'my-js-map' ); ?></label>
              <input type="text" name="overColor_all" 
              value="<?php echo esc_attr(sanitize_hex_color($my_js_map['overColor_1']) ?: '#FF0000'); ?>" />
            </p>
          </div><hr>
          <p><span class="submitbulk"><input type="submit" class="button button-primary" name="submit-clrs" value="Overwrite Colors"></span></p>
        </div>
      </div>

      <div class="map-area">
        <p class="area-name"><?php esc_html_e( 'LINK', 'my-js-map' ); ?></p>
        <div class="inner-content">
          <div class="area-url">
            <p class="link">
              <label><?php esc_html_e( 'Link', 'my-js-map' ); ?></label>
              <input type="text" name="url_all" 
              value="<?php echo esc_url( isset($my_js_map["url_1"]) ? $my_js_map["url_1"] : '' ); ?>" />
            </p>
            <p>
              <label><?php esc_html_e( 'Target', 'my-js-map' ); ?></label>
              <select name="turl_all">
                <option value="same_page" <?php if ($my_js_map['turl_1'] == 'same_page') { echo esc_attr("selected"); } ?>><?php esc_html_e( 'Same Page', 'my-js-map' ); ?></option>
                <option value="new_page" <?php if ($my_js_map['turl_1'] == 'new_page') { echo esc_attr("selected"); } ?>><?php esc_html_e( 'New Page', 'my-js-map' ); ?></option>
                <option value="none" <?php if ($my_js_map['turl_1'] == 'none') { echo esc_attr("selected"); } ?>><?php esc_html_e( 'Modal / None', 'my-js-map' ); ?></option>
              </select>
            </p>
          </div><hr>
          <p><span class="submitbulk"><input type="submit" class="button button-primary" name="submit-url" value="Overwrite Links"></span></p>
        </div>
      </div>

      <div class="map-area">
        <p class="area-name"><?php esc_html_e( 'INFO.', 'my-js-map' ); ?></p>
        <div class="inner-content">
          <div class="info">
            <p>
              <label><?php esc_html_e( 'Info.', 'my-js-map' ); ?></label>
              <textarea rows="1" name="info_all"><?php echo esc_textarea( isset($my_js_map["info_1"]) ? $my_js_map["info_1"] : '' ); ?></textarea>
            </p>
          </div><hr>
          <p><span class="submitbulk"><input type="submit" class="button button-primary" name="submit-info" value="Overwrite Info."></span></p>
        </div>
      </div>

    </div>
  </div><!-- //////////////  END BULK EDIT ///////////// -->

  <input type="hidden" name="my_js_map">

  <p class="restore-default-btn">
    <input type="submit" name="restore_default" class="button" value="<?php esc_html_e( 'Restore Default', 'my-js-map' ); ?>">
  </p>

  <div class="scroll-top"><span class="scroll-top-icon"></span></div>

</div><!-- map-admin -->
</form>
