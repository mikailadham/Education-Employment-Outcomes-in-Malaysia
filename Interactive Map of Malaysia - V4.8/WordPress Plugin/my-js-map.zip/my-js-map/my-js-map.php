<?php
/*
Plugin Name: Malaysia JS Map
Plugin URI: https://www.html5interactivemaps.com/
Description: Customize the colors, links, etc and use the shortcode in your pages.
Version: 4.8
Author: HTML5 Interactive Maps
Author URI: https://www.html5interactivemaps.com/
Text Domain: my-js-map
Domain Path: /languages
*/

declare(strict_types=1);

namespace MYJSMap;

use MYJSMap\MYJSMap;

if (!defined('MYJSMAP_VERSION')) {
    define('MYJSMAP_VERSION', '4.8');
}

if (!defined('MYJSMAP_DIR')) {
    define('MYJSMAP_DIR', plugin_dir_path(__FILE__));
}

if (!defined('MYJSMAP_URL')) {
    define('MYJSMAP_URL', plugin_dir_url(__FILE__));
}

(new MYJSMap())->init();

class MYJSMap {

    const PLUGIN_NAME = 'Malaysia JS Map';

    private $options = null;
    private $preparedOptionsList = null;

    public function init() {
        $this->initActions();
        $this->initShortcodes();
        $this->initOptions();
    }

    private function initActions() {
        if (!function_exists('wp_get_current_user')) {
            include(ABSPATH . "wp-includes/pluggable.php");
        }

        add_action('admin_menu', array($this, 'addOptionsPage'));
        add_action('admin_enqueue_scripts', array($this, 'initAdminScript'));
        add_action('init', array($this, 'loadTextdomain'));
    }

    private function initShortcodes() {
        add_shortcode('my_js_map', array($this, 'MYJSMapShortcode'));
    }

    private function initOptions() {
        $defaultOptions = $this->getDefaultOptions();
        $this->options  = get_option('my_js_map');

        if (current_user_can('manage_options')) {
            $this->updateOptions($defaultOptions);
        }

        if (!is_array($this->options)) {
            $this->options = $defaultOptions;
        }

        $this->prepareOptionsListForTpl();
    }

    public function spanTag() {
        echo wp_kses_post('<span id="myjstip"></span>');
    }

    public function AddSpanTagAdmin() {
        add_action('admin_footer', array($this, 'spanTag'));
    }

    public function AddSpanTagFront() {
        add_action('wp_footer', array($this, 'spanTag'));
    }

    public function addOptionsPage() {
        add_menu_page(
            MYJSMap::PLUGIN_NAME,
            MYJSMap::PLUGIN_NAME,
            'manage_options',
            'my-js-map',
            array($this, 'optionsScreen'),
            MYJSMAP_URL . 'includes/images/map-icon.png'
        );
    }

    /**
     * Returns the default options for the plugin.
     *
     * @return array
     */
    private function getDefaultOptions() {
        $default = array(
            'borderColor'     => '#6B8B9E',
            'showNames'       => 1,
            'namesColor'      => '#666666',
            'namesHoverColor' => '#ffffff',
            'showCallouts'    => 1,
        );

        $areas = array(
            'JOHOR DARUL TA’ZIM', 'KEDAH DARUL AMAN', 'KELANTAN DARUL NAIM', 'KUALA LUMPUR', 'LABUAN', 'MELAKA', 'NEGERI SEMBILAN DARUL KHUSUS', 'PAHANG DARUL MAKMUR', 'PERAK DARUL RIDZUAN', 'PERLIS INDERA KAYANGAN', 'PULAU PINANG', 'PUTRAJAYA', 'SABAH', 'SARAWAK', 'SELANGOR DARUL EHSAN', 'TERENGGANU DARUL IMAN'
        );

        foreach ($areas as $k => $area) {
            $default['upColor_' . ($k + 1)]   = '#f3faff';
            $default['overColor_' . ($k + 1)] = '#005999';
            $default['url_' . ($k + 1)]       = '';
            $default['turl_' . ($k + 1)]      = 'same_page';
            $default['info_' . ($k + 1)]      = $area;
            $default['active_' . ($k + 1)]    = 1;
        }

        return $default;
    }

    private function updateOptions(array $defaultOptions) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['my_js_map'])) {
                if (isset($_POST['my_js_map_nonce']) && wp_verify_nonce($_POST['my_js_map_nonce'], 'my_js_map_nonce_action')) {

                    update_option('my_js_map', $_POST);
                    $this->options = $_POST;

                    if (isset($_POST['submit-clrs'])) {
                        $i = 1;
                        while (isset($_POST['url_' . $i])) {
                            $_POST['upColor_' . $i]  = !empty($_POST['upColor_all']) ? sanitize_hex_color($_POST['upColor_all']) : '#f3faff';
                            $_POST['overColor_' . $i] = !empty($_POST['overColor_all']) ? sanitize_hex_color($_POST['overColor_all']) : '#005999';
                            $i++;
                        }
                        update_option('my_js_map', $_POST);
                        $this->options = $_POST;
                    }

                    if (isset($_POST['submit-url'])) {
                        $i = 1;
                        while (isset($_POST['url_' . $i])) {
                            $_POST['url_' . $i]  = !empty($_POST['url_all']) ? esc_url_raw($_POST['url_all']) : '';

                            $valid_turl_values = ['same_page', 'new_page', 'none'];
                            $_POST['turl_' . $i] = in_array($_POST['turl_all'], $valid_turl_values) ? $_POST['turl_all'] : 'same_page';
                            $i++;
                        }
                        update_option('my_js_map', $_POST);
                        $this->options = $_POST;
                    }

                    if (isset($_POST['submit-info'])) {
                        $i = 1;
                        while (isset($_POST['url_' . $i])) {
                            $_POST['info_' . $i] = !empty($_POST['info_all']) ? str_replace(array("\n", "\r", "\r\n"), array('', '', ''), wp_kses_post($_POST['info_all'])) : '';
                            $i++;
                        }
                        update_option('my_js_map', $_POST);
                        $this->options = $_POST;
                    }

                    if (isset($_POST['restore_default'])) {
                        update_option('my_js_map', $defaultOptions);
                        $this->options = $defaultOptions;
                    }

                } else {
                    set_transient( 'nonce_error', 'Security check failed. Please try again.', 10 );
                    return;
                }
            }
        }
    }

    private function prepareOptionsListForTpl() {
        if ($this->preparedOptionsList === null) {
            $this->preparedOptionsList = array();
            $i = 1;
            while (isset($this->options['url_' . $i])) {
                $this->preparedOptionsList[] = array(
                    'index'  => $i,
                    'info_'  => $this->options['info_' . $i],
                    'url'    => $this->options['url_' . $i],
                    'turl'   => $this->options['turl_' . $i],
                    'upColor'  => $this->options['upColor_' . $i],
                    'overColor' => $this->options['overColor_' . $i],
                    'active'   => isset($this->options['active_' . $i]),
                );
                $i++;
            }
        }
        $this->options['prepared_list'] = $this->preparedOptionsList;
    }

    public function MYJSMapShortcode() {

        $this->AddSpanTagFront();
        wp_enqueue_style('my-js-map-style-frontend', MYJSMAP_URL . 'includes/map-style.css', false, MYJSMAP_VERSION, 'all');
        wp_enqueue_script('my-js-map-config', MYJSMAP_URL . 'includes/map-config.js', array(), MYJSMAP_VERSION, true);
        wp_enqueue_script('my-js-pins', MYJSMAP_URL . 'pins-config.js?t=' . time(), array(), null, true);

        ob_start();

        include __DIR__ . "/includes/map.php";

        $js_map_config = "
            var myjsmapconfig = {
                'default': {
                    'borderColor': '" . sanitize_hex_color($this->options['borderColor']) . "',
                    'showNames': " . (isset($this->options['showNames']) ? 'true' : 'false') . ",
                    'namesColor': '" . sanitize_hex_color($this->options['namesColor']) . "',
                    'namesHoverColor': '" . sanitize_hex_color($this->options['namesHoverColor']) . "',
                    'showCallouts': " . (isset($this->options['showCallouts']) ? 'true' : 'false') . "
                },
        ";
        foreach ($this->options['prepared_list'] as $i => $item) {
            $comma = ($i < count($this->options['prepared_list']) - 1) ? ',' : '';
            $js_map_config .= "
                'myjsmap_" . esc_attr($item['index']) . "': {
                    'hover': '" . str_replace(array("\n", "\r", "\r\n", "'"), array('', '', '', "\'"), wp_kses_post($item['info_'])) . "',
                    'url': '" . esc_url($item['url']) . "',
                    'target': '" . esc_attr($item['turl']) . "',
                    'upColor': '" . sanitize_hex_color($item['upColor']) . "',
                    'overColor': '" . sanitize_hex_color($item['overColor']) . "',
                    'active': " . (isset($item['active']) && $item['active'] ? 'true' : 'false') . "
                }$comma\n";
        }

        $js_map_config .= "}";

        wp_add_inline_script('my-js-map-config', $js_map_config, 'after');

        return ob_get_clean();
    }

    public function initAdminScript() {
        if (current_user_can('manage_options') && isset($_GET['page']) && $_GET['page'] === 'my-js-map') {

            $this->AddSpanTagAdmin();

            wp_enqueue_style('my-js-map-dashboard-style', MYJSMAP_URL . 'includes/dashboard-style.css', false, MYJSMAP_VERSION, 'all');
            wp_enqueue_style('my-js-map-style', MYJSMAP_URL . 'includes/map-style.css', false, MYJSMAP_VERSION, 'all');
            wp_enqueue_script('my-js-map-config', MYJSMAP_URL . 'includes/map-config.js', array(), MYJSMAP_VERSION, true);
            wp_enqueue_script('my-js-dashboard-script', MYJSMAP_URL . 'includes/dashboard-script.js', array(), MYJSMAP_VERSION, true);
            wp_enqueue_script('my-js-pins', MYJSMAP_URL . 'pins-config.js?t=' . time(), array(), null, true);

            $js_map_config = '';

            $js_map_config .= "
                var myjsmapconfig = {
                    'default': {
                        'borderColor': '" . sanitize_hex_color($this->options['borderColor']) . "',
                        'showNames': " . (isset($this->options['showNames']) ? 'true' : 'false') . ",
                        'namesColor': '" . sanitize_hex_color($this->options['namesColor']) . "',
                        'namesHoverColor': '" . sanitize_hex_color($this->options['namesHoverColor']) . "',
                        'showCallouts': " . (isset($this->options['showCallouts']) ? 'true' : 'false') . "
                    },
            ";
            foreach ($this->options['prepared_list'] as $i => $item) {
                $comma = ($i < count($this->options['prepared_list']) - 1) ? ',' : '';
                $js_map_config .= "
                    'myjsmap_" . esc_attr($item['index']) . "': {
                        'hover': '" . str_replace(array("\n", "\r", "\r\n", "'"), array('', '', '', "\'"), wp_kses_post($item['info_'])) . "',
                        'url': '" . esc_url($item['url']) . "',
                        'target': '" . esc_attr($item['turl']) . "',
                        'upColor': '" . sanitize_hex_color($item['upColor']) . "',
                        'overColor': '" . sanitize_hex_color($item['overColor']) . "',
                        'active': " . (isset($item['active']) && $item['active'] ? 'true' : 'false') . "
                    }$comma\n";
            }

            $js_map_config .= "}";

            // Add the JavaScript inline to the page
            wp_add_inline_script('my-js-map-config', $js_map_config, 'after');
        }
    }


    public function optionsScreen() {
        include __DIR__ . "/includes/admin.php";
    }
    
    public function loadTextdomain() {
        load_plugin_textdomain( 'my-js-map', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }
}
